import assert from "node:assert/strict";
import test from "node:test";
import { DEFAULT_APPROVAL, formatRequest, nextAction, parseReply, type Approval } from "../src/lib/approval-core.ts";

const asked = (askedMs: number): Approval => ({ subject: "記事を公開", decision: "pending", askedMs, decidedMs: 0 });

test("OK / NG を読む", () => {
  assert.equal(parseReply("OK"), "ok");
  assert.equal(parseReply("おk"), "ok");
  assert.equal(parseReply("/note ok"), "ok");
  assert.equal(parseReply("やめて"), "ng");
  assert.equal(parseReply("あとで見る"), null);
});

test("承認が無ければ待つ", () => {
  assert.deepEqual(nextAction(null, DEFAULT_APPROVAL, 0), { kind: "wait", untilMs: 0 });
});

test("返事が来るまで待ち、期限を過ぎたら既定に倒れる", () => {
  const a = asked(0);
  assert.equal(nextAction(a, DEFAULT_APPROVAL, 59 * 60_000).kind, "wait");
  assert.deepEqual(nextAction(a, DEFAULT_APPROVAL, 60 * 60_000), { kind: "skip", via: "silent" });
  assert.deepEqual(nextAction(a, { waitMin: 60, silentDefault: "publish" }, 60 * 60_000), { kind: "run", via: "silent" });
});

test("人の返事が既定より優先される", () => {
  assert.deepEqual(nextAction({ ...asked(0), decision: "ok" }, DEFAULT_APPROVAL, 0), { kind: "run", via: "human" });
  assert.deepEqual(nextAction({ ...asked(0), decision: "ng" }, { waitMin: 1, silentDefault: "publish" }, 9e9), { kind: "skip", via: "human" });
});

test("承認文に待ち時間と既定の動きが入る", () => {
  const text = formatRequest("記事を公開", "タイトル: テスト", DEFAULT_APPROVAL);
  assert.match(text, /60 分/);
  assert.match(text, /見送ります/);
});
