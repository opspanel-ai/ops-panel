import assert from "node:assert/strict";
import test from "node:test";
import { countTasks, dueToday, makeTask, normalizeTasks, setStatus } from "../src/lib/tasks-core.ts";

test("壊れた保存データは落として読む", () => {
  const list = normalizeTasks([{ title: "生きてる" }, { title: "   " }, null, 5, { title: "期日つき", due: "2026-01-02", status: "doing" }]);
  assert.equal(list.length, 2);
  assert.equal(list[1]?.due, "2026-01-02");
  assert.equal(list[1]?.status, "doing");
});

test("不正な日付・状態は既定値に寄せる", () => {
  const list = normalizeTasks([{ title: "x", due: "2026/01/02", status: "burning" }]);
  assert.equal(list[0]?.due, "");
  assert.equal(list[0]?.status, "todo");
});

test("今日ぶんは 期日 → 作成順、期日なしは最後", () => {
  const base = [
    { id: "a", title: "期日なし", status: "todo" as const, due: "", createdMs: 1 },
    { id: "b", title: "明後日", status: "todo" as const, due: "2026-03-03", createdMs: 2 },
    { id: "c", title: "昨日", status: "todo" as const, due: "2026-03-01", createdMs: 3 },
    { id: "d", title: "済", status: "done" as const, due: "2026-03-01", createdMs: 4 },
  ];
  assert.deepEqual(dueToday(base, "2026-03-02").map((t) => t.id), ["c", "a"]);
});

test("期限切れを数える", () => {
  const list = normalizeTasks([
    { title: "遅れ", due: "2026-03-01" },
    { title: "今日", due: "2026-03-02" },
    { title: "済", due: "2026-02-01", status: "done" },
  ]);
  assert.deepEqual(countTasks(list, "2026-03-02"), { todo: 2, doing: 0, done: 1, overdue: 1 });
});

test("makeTask は空タイトルを拒む / 状態は書き換えられる", () => {
  assert.equal(makeTask("  ", "", 1), null);
  const t = makeTask("買い物", "2026-03-02", 1);
  assert.ok(t);
  assert.equal(setStatus([t], t.id, "done")[0]?.status, "done");
});
