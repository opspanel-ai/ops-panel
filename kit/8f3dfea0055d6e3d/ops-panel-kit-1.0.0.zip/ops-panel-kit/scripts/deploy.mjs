// 「型 → lint → テスト → ビルド」を順に通し、どれかが落ちたら止める。通ったときだけ起動を入れ替える。
// AI にコードを書かせるなら、この門を必ず通すこと。人が見るより先に機械が落とす方が速くて確実。
//   node scripts/deploy.mjs          通ったらビルドまで
//   node scripts/deploy.mjs --check  ビルドせず検査だけ
import { spawnSync } from "node:child_process";

const CHECK_ONLY = process.argv.includes("--check");
// Windows の pnpm は .cmd なので shell 経由でしか起動できない (Node 20 以降は .cmd の直接起動を拒む)。
// shell: true に args 配列を渡すと DEP0190 の警告が出るため、コマンドは 1 本の文字列で渡す。
// ここで組む文字列は下の固定値だけで、外から来た値は入らない。
const steps = [
  ["型チェック", "pnpm typecheck"],
  ["テスト", "pnpm test"],
  ...(CHECK_ONLY ? [] : [["ビルド", "pnpm build"]]),
];

for (const [label, command] of steps) {
  process.stdout.write(`\n== ${label}\n`);
  const r = spawnSync(command, { stdio: "inherit", shell: true });
  if (r.status !== 0) {
    console.error(`\n✗ ${label} で失敗。ここで止めます（本番は入れ替えません）。`);
    process.exit(1);
  }
}
console.log("\n✓ 全部通りました。");
