// data/ をリポジトリの外へ退避する。git の操作ミス・ビルドの事故で消えるのは「作ったコード」ではなく
// 「貯めたデータ」なので、こちらだけは外に出す。世代を残し、古いものから消す。
//   node scripts/backup.mjs            既定 30 世代
//   PANEL_BACKUP_DIR=D:/backups node scripts/backup.mjs
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";

const DATA = process.env.PANEL_DATA_DIR?.trim() || path.join(process.cwd(), "data");
const DEST = process.env.PANEL_BACKUP_DIR?.trim() || path.join(os.homedir(), "panel-backups");
const KEEP = Number(process.env.PANEL_BACKUP_KEEP || 30);

const stamp = () => new Date(Date.now() + 9 * 3600_000).toISOString().replace(/[-:T]/g, "").slice(0, 14);

async function main() {
  const files = await fs.readdir(DATA).catch(() => []);
  const json = files.filter((f) => f.endsWith(".json"));
  if (json.length === 0) {
    console.log("退避するものがありません:", DATA);
    return;
  }
  const dir = path.join(DEST, stamp());
  await fs.mkdir(dir, { recursive: true });
  for (const f of json) await fs.copyFile(path.join(DATA, f), path.join(dir, f));
  console.log(`退避 ${json.length} 件 -> ${dir}`);

  const gens = (await fs.readdir(DEST)).filter((d) => /^\d{14}$/.test(d)).sort();
  for (const old of gens.slice(0, Math.max(0, gens.length - KEEP))) {
    await fs.rm(path.join(DEST, old), { recursive: true, force: true });
    console.log("古い世代を削除:", old);
  }
}

main().catch((e) => {
  console.error("バックアップ失敗:", e.message);
  process.exit(1);
});
