/** @type {import('next').NextConfig} */
// 自宅 PC で常駐させる前提。`pnpm build` → `pnpm start` で 127.0.0.1:4320 に立てる。
//
// output: "standalone" は使わない — Windows は symlink の権限が無いと EPERM でビルドが落ちる
// （開発者モード or 管理者が要る）。購入者の環境を選ぶ設定を既定にしない。
//
// outputFileTracingRoot を自分のフォルダに固定する — 親フォルダに別のロックファイルがあると
// Next.js がそちらを作業根と誤認して警告を出す（実害は出ないが、原因探しの時間を奪う）。
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));

const nextConfig = {
  reactStrictMode: true,
  outputFileTracingRoot: here,
};
export default nextConfig;
