# 業務パネル キット

自分専用の管理画面を、**サーバーを借りずに自宅 PC で常駐**させるための最小の骨格です。
ここに入っているのは「どこでも同じように効く部分」だけ。業務の中身は入っていないので、
あなたの仕事に合わせて足していく前提で作ってあります。

## 15 分で動かす

```bash
pnpm install
cp .env.example .env     # Windows は copy
pnpm dev                 # http://127.0.0.1:4320
```

「今日やること」が出れば成功です。データは `data/tasks.json` に入ります（DB は使いません）。

## 入っているもの

| 置き場 | 役 |
|---|---|
| `src/lib/tasks-core.ts` | 判断する純ロジック（I/O なし・テストできる） |
| `src/lib/approval-core.ts` | 「AI にやらせる前に人の OK を待つ」の判断 |
| `src/lib/store.ts` | JSON をデータベース代わりに使う口（一時ファイル → rename で壊さない） |
| `src/lib/telegram.ts` | webhook 無しの Telegram（getUpdates。固定 IP も ngrok も要らない） |
| `src/app/api/*` | 画面と外から叩く口 |
| `scripts/backup.mjs` | data/ をリポジトリ**外**へ世代退避 |
| `scripts/deploy.mjs` | 型 → テスト → ビルドの門。落ちたら止める |
| `scripts/install-task.ps1` | Windows タスクスケジューラへ常駐登録（電源が入れば勝手に上がる） |
| `prompts/*.md` | AI に投げる文の型（改善要望 / 記事下書き / 表紙画像） |

## この骨格の考え方（ここが本体）

1. **判断と I/O を分ける。** 決めるコードは `*-core.ts` に置き、fs や fetch を混ぜない。
   AI にコードを書かせるとき、純ロジックだけ読ませれば事故が減り、テストもそのまま書ける。
2. **データは JSON、ただし壊さない工夫だけ入れる。** 一時ファイル → rename、1 世代の `.bak`、
   リポジトリ外への定期退避。個人事業の規模なら DB を立てる前にここで足りる。
3. **人の承認を 1 か所に集める。** 画面のボタンも Telegram の返信も同じ `approval-core` を通す。
   口が 2 つあると片方の規則が必ず古くなる。
4. **返事が無いときの既定を先に決める。** 承認待ちで止まり続ける自動化は使われなくなる。
5. **門を通ったものだけ本番へ。** `scripts/deploy.mjs` が型・テスト・ビルドを順に見る。

## 常駐させる（Windows）

```powershell
powershell -ExecutionPolicy Bypass -File scripts/install-task.ps1
schtasks /run /tn ops-panel
```

停止は `schtasks /end /tn ops-panel`、解除は `schtasks /delete /tn ops-panel /f`。

## バックアップ

```bash
PANEL_BACKUP_DIR=D:/panel-backups node scripts/backup.mjs
```

30 分ごとに走らせるなら、同じくタスクスケジューラに登録してください。
**退避先はリポジトリの外**にします（git の操作ミスで消えるのはデータの方です）。

## Telegram で承認を受け取る

1. BotFather でボットを作り、トークンを `.env` の `PANEL_TELEGRAM_TOKEN` に
2. そのボットに一度話しかける
3. `PANEL_TELEGRAM_CHAT_ID` に自分の chat id を入れる
4. `POST /api/approve {"op":"ask","subject":"記事を公開","detail":"..."}` で承認依頼
5. `POST /api/approve {"op":"poll"}` を定期的に叩くと、OK / NG の返信を拾う

webhook を使わないので、ルーターのポート開放も固定 IP も不要です。

## AI に改善させる回し方

1. `prompts/improve.md` に要望を 1 つだけ書いて AI に渡す
2. AI が直す
3. `node scripts/deploy.mjs --check` が通るまで AI 自身に直させる
4. 通ったら `pnpm build` → 常駐を入れ替え

要望を 2 つ以上まとめて渡すと、落ちたときにどちらが原因か分からなくなります。必ず 1 つずつ。

## 入っていないもの（意図的に）

認証、複数ユーザー、外部 API 連携、グラフ。どれも「あなたの業務が決まってから」足す部分です。
骨格に先に入れると、使わない機能の保守だけが残ります。

ライセンスは `LICENSE-KIT.md`。
