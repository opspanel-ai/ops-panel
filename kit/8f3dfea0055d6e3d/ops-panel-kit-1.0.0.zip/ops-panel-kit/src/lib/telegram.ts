// webhook を使わない Telegram の口。自宅 PC は外から叩けないので、こちらから取りに行く（getUpdates）。
// 固定 IP も ngrok も要らない。資格情報は .env だけに置き、画面やログには出さない。
const API = "https://api.telegram.org";

interface TelegramMessage {
  text?: string;
  chat?: { id?: number };
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

export interface Incoming {
  updateId: number;
  chatId: number;
  text: string;
}

function token(): string {
  return process.env.PANEL_TELEGRAM_TOKEN?.trim() ?? "";
}

export function telegramReady(): boolean {
  return token().length > 0 && (process.env.PANEL_TELEGRAM_CHAT_ID?.trim() ?? "").length > 0;
}

export async function sendMessage(text: string): Promise<boolean> {
  if (!telegramReady()) return false;
  const res = await fetch(`${API}/bot${token()}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: process.env.PANEL_TELEGRAM_CHAT_ID, text, disable_web_page_preview: true }),
  });
  return res.ok;
}

/** offset 以降の受信。返り値の最大 updateId + 1 を次の offset に使う（同じ更新を二度読まない）。 */
export async function poll(offset: number): Promise<Incoming[]> {
  if (!telegramReady()) return [];
  const res = await fetch(`${API}/bot${token()}/getUpdates?timeout=0&offset=${offset}`);
  if (!res.ok) return [];
  const body = (await res.json()) as { ok?: boolean; result?: TelegramUpdate[] };
  const updates = body.ok === true && Array.isArray(body.result) ? body.result : [];
  return updates.flatMap((u) => {
    const text = u.message?.text ?? "";
    const chatId = u.message?.chat?.id ?? 0;
    return text && chatId ? [{ updateId: u.update_id, chatId, text }] : [];
  });
}
