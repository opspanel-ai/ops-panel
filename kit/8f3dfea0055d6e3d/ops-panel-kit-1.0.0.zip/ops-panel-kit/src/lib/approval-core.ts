// 「AI が勝手にやる」を安全にするための承認の純ロジック。
// 考え方: 危ないことほど *人の OK を待つ*。ただし待ちっぱなしで止まらないよう、返事が無いときの
// 既定の動き（publish = やる / skip = 見送る）を先に決めておく。ここに時刻は持たない（呼び出し側が渡す）。

export type Decision = "pending" | "ok" | "ng";
export type SilentDefault = "publish" | "skip";

export interface Approval {
  /** 何に対する承認か（記事 id・コマンド名など） */
  subject: string;
  decision: Decision;
  askedMs: number;
  decidedMs: number;
}

export interface ApprovalConfig {
  /** 返事が無いまま次に進めるまでの分 */
  waitMin: number;
  silentDefault: SilentDefault;
}

export const DEFAULT_APPROVAL: ApprovalConfig = { waitMin: 60, silentDefault: "skip" };

const OK_RE = /^(ok|okay|オーケー|おk|はい|yes|go|公開|やって|👍|⭕|○|〇)$/i;
const NG_RE = /^(ng|no|だめ|ダメ|見送り|やめ|やめて|止めて|stop|skip|スキップ|❌|✖|×)$/i;

/** 人の返信を OK / NG に読む。どちらでもなければ null（ふつうの発言として扱う）。 */
export function parseReply(text: string): "ok" | "ng" | null {
  const t = text.trim().replace(/^\/\w+\s*/, "");
  if (OK_RE.test(t)) return "ok";
  if (NG_RE.test(t)) return "ng";
  return null;
}

export type Next =
  | { kind: "wait"; untilMs: number }
  | { kind: "run"; via: "human" | "silent" }
  | { kind: "skip"; via: "human" | "silent" };

/** いま何をしてよいか。承認が無ければ「待つ」。 */
export function nextAction(a: Approval | null, config: ApprovalConfig, nowMs: number): Next {
  if (!a) return { kind: "wait", untilMs: 0 };
  if (a.decision === "ok") return { kind: "run", via: "human" };
  if (a.decision === "ng") return { kind: "skip", via: "human" };
  const deadline = a.askedMs + config.waitMin * 60_000;
  if (nowMs < deadline) return { kind: "wait", untilMs: deadline };
  return config.silentDefault === "publish" ? { kind: "run", via: "silent" } : { kind: "skip", via: "silent" };
}

/** 承認を求める文（Telegram の markdown は記号で壊れるので平文）。 */
export function formatRequest(subject: string, detail: string, config: ApprovalConfig): string {
  const fallback = config.silentDefault === "publish" ? "実行します" : "見送ります";
  return [`【承認】${subject}`, detail, "", `OK / NG で返信してください。${config.waitMin} 分返事が無ければ ${fallback}。`].join("\n");
}
