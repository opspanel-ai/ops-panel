// JSON ファイルをデータベース代わりに使うための最小の口。DB を立てない代わりに、壊さない工夫だけ入れる。
//   1) 書くときは 一時ファイル → rename（途中で電源が落ちても半端な JSON が残らない）
//   2) 読めない JSON は例外にせず fallback を返す（画面が落ちない）
//   3) 書く前に 1 世代だけ .bak を残す
// 同時に書くプロセスが複数あるなら、ここにロックを足すこと（1 プロセスなら不要）。
import { promises as fs } from "node:fs";
import path from "node:path";

const DATA_DIR = process.env.PANEL_DATA_DIR?.trim() || path.join(process.cwd(), "data");

export function dataPath(name: string): string {
  if (!/^[\w.-]+$/.test(name)) throw new Error(`不正なファイル名: ${name}`);
  return path.join(DATA_DIR, name);
}

export async function readJson<T>(name: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(dataPath(name), "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function writeJson(name: string, value: unknown): Promise<void> {
  const file = dataPath(name);
  await fs.mkdir(path.dirname(file), { recursive: true });
  try {
    await fs.copyFile(file, `${file}.bak`);
  } catch {
    // 初回は元ファイルが無い。失敗しても書き込みは続ける。
  }
  const tmp = `${file}.tmp-${process.pid}`;
  await fs.writeFile(tmp, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(tmp, file);
}

/** 読む → 変える → 書く をまとめた形。純ロジックを渡すだけで使えるようにしてある。 */
export async function updateJson<T>(name: string, fallback: T, change: (current: T) => T): Promise<T> {
  const next = change(await readJson<T>(name, fallback));
  await writeJson(name, next);
  return next;
}
