// 画面に出る「今日やること」の純ロジック。I/O を持たないので、そのままテストできる。
// この分け方がキットの肝: 「決める」= *-core.ts（純粋・テスト可能）、「触る」= sources/*.ts（fs・fetch）。
// AI にコードを書かせるとき、純ロジック側だけを読ませれば事故が起きにくい。

export type TaskStatus = "todo" | "doing" | "done";

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  /** "YYYY-MM-DD"。空なら期日なし。 */
  due: string;
  createdMs: number;
}

export const TITLE_MAX = 200;
export const KEEP = 500;

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const STATUSES: readonly TaskStatus[] = ["todo", "doing", "done"];

export function cleanTitle(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const t = v.replace(/\s+/g, " ").trim().slice(0, TITLE_MAX);
  return t.length > 0 ? t : null;
}

export function cleanDay(v: unknown): string {
  return typeof v === "string" && DAY_RE.test(v) ? v : "";
}

export function asStatus(v: unknown): TaskStatus {
  return typeof v === "string" && (STATUSES as readonly string[]).includes(v) ? (v as TaskStatus) : "todo";
}

export function makeTask(title: unknown, due: unknown, nowMs: number): Task | null {
  const t = cleanTitle(title);
  if (!t) return null;
  return { id: `t-${nowMs.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`, title: t, status: "todo", due: cleanDay(due), createdMs: nowMs };
}

/** 保存済みの配列を安全な形に整える。壊れた要素は落とす。何度かけても結果は同じ。 */
export function normalizeTasks(raw: unknown): Task[] {
  if (!Array.isArray(raw)) return [];
  const out: Task[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) continue;
    const r = item as Record<string, unknown>;
    const title = cleanTitle(r.title);
    if (!title) continue;
    const createdMs = typeof r.createdMs === "number" && Number.isFinite(r.createdMs) ? r.createdMs : 0;
    const id = typeof r.id === "string" && r.id ? r.id : `t-${out.length}`;
    out.push({ id, title, status: asStatus(r.status), due: cleanDay(r.due), createdMs });
  }
  return out.slice(0, KEEP);
}

export function setStatus(list: readonly Task[], id: string, status: TaskStatus): Task[] {
  return list.map((t) => (t.id === id ? { ...t, status } : t));
}

export function removeTask(list: readonly Task[], id: string): Task[] {
  return list.filter((t) => t.id !== id);
}

/** 今日出すぶん: 未完で、期日が今日まで（期日なしは最後）。並びは 期日 → 作成順。 */
export function dueToday(list: readonly Task[], today: string): Task[] {
  return list
    .filter((t) => t.status !== "done" && (t.due === "" || t.due <= today))
    .sort((a, b) => (a.due === b.due ? a.createdMs - b.createdMs : a.due === "" ? 1 : b.due === "" ? -1 : a.due < b.due ? -1 : 1));
}

export interface TaskCounts {
  todo: number;
  doing: number;
  done: number;
  overdue: number;
}

export function countTasks(list: readonly Task[], today: string): TaskCounts {
  return {
    todo: list.filter((t) => t.status === "todo").length,
    doing: list.filter((t) => t.status === "doing").length,
    done: list.filter((t) => t.status === "done").length,
    overdue: list.filter((t) => t.status !== "done" && t.due !== "" && t.due < today).length,
  };
}
