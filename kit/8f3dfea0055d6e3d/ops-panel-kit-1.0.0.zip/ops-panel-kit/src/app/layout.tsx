import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "業務パネル",
  description: "自分専用の管理画面",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
