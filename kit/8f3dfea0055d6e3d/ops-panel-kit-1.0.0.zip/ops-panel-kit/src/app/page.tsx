"use client";

import { useCallback, useEffect, useState } from "react";
import type { Task, TaskCounts, TaskStatus } from "@/lib/tasks-core";

interface Payload {
  today: string;
  tasks: Task[];
  counts: TaskCounts;
}

const EMPTY: Payload = { today: "", tasks: [], counts: { todo: 0, doing: 0, done: 0, overdue: 0 } };

export default function Page() {
  const [data, setData] = useState<Payload>(EMPTY);
  const [title, setTitle] = useState("");

  const load = useCallback(async () => {
    const res = await fetch("/api/tasks", { cache: "no-store" });
    if (res.ok) setData((await res.json()) as Payload);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const send = useCallback(
    async (body: Record<string, string>) => {
      await fetch("/api/tasks", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      await load();
    },
    [load],
  );

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await send({ op: "add", title });
    setTitle("");
  };

  const next: Record<TaskStatus, TaskStatus> = { todo: "doing", doing: "done", done: "todo" };

  return (
    <main>
      <h1>今日やること</h1>
      <p className="sub">{data.today}</p>

      <div className="card counts">
        <div>未着手<b>{data.counts.todo}</b></div>
        <div>進行中<b>{data.counts.doing}</b></div>
        <div>完了<b>{data.counts.done}</b></div>
        <div>期限切れ<b>{data.counts.overdue}</b></div>
      </div>

      <div className="card">
        {data.tasks.length === 0 && <p className="empty">やることはありません。</p>}
        {data.tasks.map((t) => (
          <div key={t.id} className={`row ${t.status === "done" ? "done" : ""}`}>
            <button onClick={() => void send({ op: "status", id: t.id, status: next[t.status] })}>
              {t.status === "todo" ? "□" : t.status === "doing" ? "◐" : "■"}
            </button>
            <span className="title">{t.title}</span>
            {t.due && <span className={`due ${data.today && t.due < data.today ? "over" : ""}`}>{t.due}</span>}
            <button onClick={() => void send({ op: "remove", id: t.id })}>消す</button>
          </div>
        ))}
      </div>

      <form onSubmit={(e) => void add(e)} className="card">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="やることを書いて Enter" />
        <button className="primary" type="submit">足す</button>
      </form>
    </main>
  );
}
