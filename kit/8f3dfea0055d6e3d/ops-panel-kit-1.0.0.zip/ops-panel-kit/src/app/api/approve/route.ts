// 承認の口。画面の「OK」ボタンと、Telegram の返信の両方がここを通る（判断は 1 か所にまとめる）。
import { NextResponse } from "next/server";
import { readJson, writeJson } from "@/lib/store";
import { DEFAULT_APPROVAL, formatRequest, nextAction, parseReply, type Approval } from "@/lib/approval-core";
import { poll, sendMessage, telegramReady } from "@/lib/telegram";

export const dynamic = "force-dynamic";

const FILE = "approval.json";

interface Stored {
  current: Approval | null;
  offset: number;
}

const EMPTY: Stored = { current: null, offset: 0 };

export async function GET() {
  const stored = await readJson<Stored>(FILE, EMPTY);
  return NextResponse.json({ ...stored, next: nextAction(stored.current, DEFAULT_APPROVAL, Date.now()), telegram: telegramReady() });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const op = typeof body.op === "string" ? body.op : "";
  const stored = await readJson<Stored>(FILE, EMPTY);

  if (op === "ask") {
    const subject = typeof body.subject === "string" ? body.subject : "確認";
    const detail = typeof body.detail === "string" ? body.detail : "";
    const current: Approval = { subject, decision: "pending", askedMs: Date.now(), decidedMs: 0 };
    await writeJson(FILE, { ...stored, current });
    await sendMessage(formatRequest(subject, detail, DEFAULT_APPROVAL));
    return NextResponse.json({ ok: true });
  }

  if (op === "decide") {
    const decision = body.decision === "ok" ? "ok" : "ng";
    if (!stored.current) return NextResponse.json({ ok: false, error: "承認待ちがありません" }, { status: 400 });
    await writeJson(FILE, { ...stored, current: { ...stored.current, decision, decidedMs: Date.now() } });
    return NextResponse.json({ ok: true });
  }

  if (op === "poll") {
    const incoming = await poll(stored.offset);
    let next = stored;
    for (const msg of incoming) {
      next = { ...next, offset: Math.max(next.offset, msg.updateId + 1) };
      const reply = parseReply(msg.text);
      if (reply && next.current && next.current.decision === "pending") {
        next = { ...next, current: { ...next.current, decision: reply, decidedMs: Date.now() } };
      }
    }
    await writeJson(FILE, next);
    return NextResponse.json({ ok: true, read: incoming.length, current: next.current });
  }

  return NextResponse.json({ ok: false, error: `不明な操作: ${op}` }, { status: 400 });
}
