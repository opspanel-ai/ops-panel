import { NextResponse } from "next/server";
import { readJson, writeJson } from "@/lib/store";
import { countTasks, dueToday, makeTask, normalizeTasks, removeTask, setStatus, asStatus, type Task } from "@/lib/tasks-core";

export const dynamic = "force-dynamic";

const FILE = "tasks.json";

/** JST の「今日」。サーバーの時計がどこにあっても同じ日付になるよう、オフセットで寄せる。 */
function todayJst(): string {
  const d = new Date(Date.now() + 9 * 3600_000);
  return d.toISOString().slice(0, 10);
}

async function load(): Promise<Task[]> {
  return normalizeTasks(await readJson<unknown>(FILE, []));
}

export async function GET() {
  const tasks = await load();
  const today = todayJst();
  return NextResponse.json({ today, tasks: dueToday(tasks, today), counts: countTasks(tasks, today) });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const op = typeof body.op === "string" ? body.op : "";
  const id = typeof body.id === "string" ? body.id : "";
  const tasks = await load();

  if (op === "add") {
    const task = makeTask(body.title, body.due, Date.now());
    if (!task) return NextResponse.json({ ok: false, error: "タイトルが空です" }, { status: 400 });
    await writeJson(FILE, [task, ...tasks]);
    return NextResponse.json({ ok: true });
  }
  if (op === "status" && id) {
    await writeJson(FILE, setStatus(tasks, id, asStatus(body.status)));
    return NextResponse.json({ ok: true });
  }
  if (op === "remove" && id) {
    await writeJson(FILE, removeTask(tasks, id));
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ ok: false, error: `不明な操作: ${op}` }, { status: 400 });
}
