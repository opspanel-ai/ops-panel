# Cover image, written as HTML

Write a single 1280×670 HTML page. A screenshot of it becomes the cover image.

- The title is the only text. No descriptions (they become unreadable when scaled down)
- One solid colour or one gradient as the background. No photographs
- No external CSS, fonts or images — one self-contained file
- Output the HTML only.
