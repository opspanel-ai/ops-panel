# Work log → article draft

Write an article in Markdown from the material below.

## Material
<!-- Paste what you actually did today: what broke, what fixed it, the commands -->

## Shape
- Title: include the words someone would search for. No hype.
- Body: 1) what the problem was 2) how you thought about it 3) the actual steps, commands and settings
  included 4) what tripped you up and how you got past it
- Leave out: business names, shop names, clients, locations, personal names
- Banned: claims that cannot be checked ("guaranteed", "anyone can", "100%")
- Output the article only. No preamble.
