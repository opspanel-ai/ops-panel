# Change request → let the AI implement it

You are responsible for this repository. Implement the request below.

## Request
<!-- One request only. Two or more go in separate rounds -->

## Rules
- Touch only files the request is about. No formatting, renaming or dependency bumps on the side.
- Code that decides goes in `src/lib/*-core.ts` (pure, no I/O). Keep `fs` / `fetch` in their own files.
- No `any`. Use `unknown` with narrowing, or define the type.
- Functions under 50 lines. No nesting deeper than 3 levels.
- Comments say **why**, never what.

## Before you finish, always
1. `pnpm typecheck`
2. `pnpm test` (add tests when you change a decision function)
3. `node scripts/deploy.mjs --check`
4. If it fails, fix it. If you cannot, **report what failed and stop**. Do not report success.
