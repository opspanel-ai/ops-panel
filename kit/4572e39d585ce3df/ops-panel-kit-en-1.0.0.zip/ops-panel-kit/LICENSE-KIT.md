# Terms of use

- You (and your business) may use this freely, including in commercial work. Modify it as you like.
- Use it internally, hand it to your staff, build it into something you deliver to a client — all fine.
- **Redistributing, reselling or publishing this kit itself (the files or the text) is not allowed.**
- Provided as is, with no warranty. Run `scripts/backup.mjs` before you point it at real data.
- Individual support and installation help are not included.
