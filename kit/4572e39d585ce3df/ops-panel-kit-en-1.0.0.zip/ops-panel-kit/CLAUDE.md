# Rules for the AI working in this repository

> Written to be handed to an AI coding agent (Claude Code, Codex, Cursor, …) as-is.
> Put it at the repository root and it applies without repeating yourself in every prompt.

## Structure
- Code that decides lives in `src/lib/*-core.ts`: pure functions, no I/O, and **no clock** — take the
  time as an argument
- `fs` / `fetch` / browser automation live in their own files. Never mixed into the decision layer
- Screens live in `src/app/`. No logic in the screen (it stops being testable)

## Types
- No `any`. Use `unknown` plus narrowing, or define the union
- Anything from outside (requests, JSON files, environment variables) is normalized before use
- A broken saved file must not break the screen. Run it through `normalize*` and fall back to defaults

## Size
- Functions stay under 50 lines, take at most 3 arguments, and nest at most 3 levels

## Comments
- Write **why**, never what. The code already says what
- Leave the comments describing past accidents in place. Delete them and the accident comes back

## Before you finish
1. `pnpm typecheck`
2. `pnpm test`
3. `node scripts/deploy.mjs --check`
4. If it fails, fix it. If you cannot, **report the failure as it is and stop**. Do not claim success

## Never
- Run `git push --force`, `git reset --hard` or `rm -rf` without asking
- Delete or recreate `data/`
- Reformat, rename or bump dependencies that the request did not ask about
- Put secrets in code, JSON or logs. They live in `.env` only
