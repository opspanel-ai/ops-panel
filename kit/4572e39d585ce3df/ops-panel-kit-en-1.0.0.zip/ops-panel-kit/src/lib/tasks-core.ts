// The decision logic behind "today's tasks". No I/O, so it is testable as it stands.
// This split is the point of the kit: *-core.ts decides (pure, testable); the I/O files touch
// (fs, fetch). When an AI writes code, handing it only the decision layer prevents most accidents.

export type TaskStatus = "todo" | "doing" | "done";

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  /** "YYYY-MM-DD". Empty means no due date. */
  due: string;
  createdMs: number;
}

export const TITLE_MAX = 200;
export const KEEP = 500;

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const STATUSES: readonly TaskStatus[] = ["todo", "doing", "done"];

export function cleanTitle(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const t = v.replace(/\s+/g, " ").trim().slice(0, TITLE_MAX);
  return t.length > 0 ? t : null;
}

export function cleanDay(v: unknown): string {
  return typeof v === "string" && DAY_RE.test(v) ? v : "";
}

export function asStatus(v: unknown): TaskStatus {
  return typeof v === "string" && (STATUSES as readonly string[]).includes(v) ? (v as TaskStatus) : "todo";
}

export function makeTask(title: unknown, due: unknown, nowMs: number): Task | null {
  const t = cleanTitle(title);
  if (!t) return null;
  return { id: `t-${nowMs.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`, title: t, status: "todo", due: cleanDay(due), createdMs: nowMs };
}

/** Bring a saved array into a safe shape. Broken entries are dropped. Idempotent. */
export function normalizeTasks(raw: unknown): Task[] {
  if (!Array.isArray(raw)) return [];
  const out: Task[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) continue;
    const r = item as Record<string, unknown>;
    const title = cleanTitle(r.title);
    if (!title) continue;
    const createdMs = typeof r.createdMs === "number" && Number.isFinite(r.createdMs) ? r.createdMs : 0;
    const id = typeof r.id === "string" && r.id ? r.id : `t-${out.length}`;
    out.push({ id, title, status: asStatus(r.status), due: cleanDay(r.due), createdMs });
  }
  return out.slice(0, KEEP);
}

export function setStatus(list: readonly Task[], id: string, status: TaskStatus): Task[] {
  return list.map((t) => (t.id === id ? { ...t, status } : t));
}

export function removeTask(list: readonly Task[], id: string): Task[] {
  return list.filter((t) => t.id !== id);
}

/** Due today: unfinished and due on or before today (no due date sorts last). Ordered by due date, then creation. */
export function dueToday(list: readonly Task[], today: string): Task[] {
  return list
    .filter((t) => t.status !== "done" && (t.due === "" || t.due <= today))
    .sort((a, b) => (a.due === b.due ? a.createdMs - b.createdMs : a.due === "" ? 1 : b.due === "" ? -1 : a.due < b.due ? -1 : 1));
}

export interface TaskCounts {
  todo: number;
  doing: number;
  done: number;
  overdue: number;
}

export function countTasks(list: readonly Task[], today: string): TaskCounts {
  return {
    todo: list.filter((t) => t.status === "todo").length,
    doing: list.filter((t) => t.status === "doing").length,
    done: list.filter((t) => t.status === "done").length,
    overdue: list.filter((t) => t.status !== "done" && t.due !== "" && t.due < today).length,
  };
}
