// Telegram without webhooks. A home PC cannot be reached from outside, so we fetch instead
// (getUpdates). No static IP, no tunnel. The token lives in .env only — never in a screen or a log.
const API = "https://api.telegram.org";

interface TelegramMessage {
  text?: string;
  chat?: { id?: number };
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

export interface Incoming {
  updateId: number;
  chatId: number;
  text: string;
}

function token(): string {
  return process.env.PANEL_TELEGRAM_TOKEN?.trim() ?? "";
}

export function telegramReady(): boolean {
  return token().length > 0 && (process.env.PANEL_TELEGRAM_CHAT_ID?.trim() ?? "").length > 0;
}

export async function sendMessage(text: string): Promise<boolean> {
  if (!telegramReady()) return false;
  const res = await fetch(`${API}/bot${token()}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: process.env.PANEL_TELEGRAM_CHAT_ID, text, disable_web_page_preview: true }),
  });
  return res.ok;
}

/** Messages after `offset`. Pass back max(updateId) + 1 next time so nothing is read twice. */
export async function poll(offset: number): Promise<Incoming[]> {
  if (!telegramReady()) return [];
  const res = await fetch(`${API}/bot${token()}/getUpdates?timeout=0&offset=${offset}`);
  if (!res.ok) return [];
  const body = (await res.json()) as { ok?: boolean; result?: TelegramUpdate[] };
  const updates = body.ok === true && Array.isArray(body.result) ? body.result : [];
  return updates.flatMap((u) => {
    const text = u.message?.text ?? "";
    const chatId = u.message?.chat?.id ?? 0;
    return text && chatId ? [{ updateId: u.update_id, chatId, text }] : [];
  });
}
