// The decision logic that makes "the AI just does it" safe.
// The idea: the riskier the step, the more it waits for a human OK. To stop it waiting forever,
// every approval carries a default action for "nobody answered" (publish = do it / skip = drop it).
// No clock in here — the caller passes the time.

export type Decision = "pending" | "ok" | "ng";
export type SilentDefault = "publish" | "skip";

export interface Approval {
  /** What is being approved (article id, command name, …) */
  subject: string;
  decision: Decision;
  askedMs: number;
  decidedMs: number;
}

export interface ApprovalConfig {
  /** Minutes to wait before moving on without an answer */
  waitMin: number;
  silentDefault: SilentDefault;
}

export const DEFAULT_APPROVAL: ApprovalConfig = { waitMin: 60, silentDefault: "skip" };

const OK_RE = /^(ok|okay|yes|go|do it|sure|👍|⭕)$/i;
const NG_RE = /^(ng|no|nope|stop|skip|cancel|❌|✖)$/i;

/** Read a human reply as OK / NG. Anything else is null (ordinary chatter). */
export function parseReply(text: string): "ok" | "ng" | null {
  const t = text.trim().replace(/^\/\w+\s*/, "");
  if (OK_RE.test(t)) return "ok";
  if (NG_RE.test(t)) return "ng";
  return null;
}

export type Next =
  | { kind: "wait"; untilMs: number }
  | { kind: "run"; via: "human" | "silent" }
  | { kind: "skip"; via: "human" | "silent" };

/** What is allowed right now. With no approval on file, wait. */
export function nextAction(a: Approval | null, config: ApprovalConfig, nowMs: number): Next {
  if (!a) return { kind: "wait", untilMs: 0 };
  if (a.decision === "ok") return { kind: "run", via: "human" };
  if (a.decision === "ng") return { kind: "skip", via: "human" };
  const deadline = a.askedMs + config.waitMin * 60_000;
  if (nowMs < deadline) return { kind: "wait", untilMs: deadline };
  return config.silentDefault === "publish" ? { kind: "run", via: "silent" } : { kind: "skip", via: "silent" };
}

/** The approval request text (plain text — Telegram markdown breaks on punctuation). */
export function formatRequest(subject: string, detail: string, config: ApprovalConfig): string {
  const fallback = config.silentDefault === "publish" ? "it runs" : "it is skipped";
  return [`[approval] ${subject}`, detail, "", `Reply OK or NG. With no reply in ${config.waitMin} minutes: ${fallback}.`].join("\n");
}
