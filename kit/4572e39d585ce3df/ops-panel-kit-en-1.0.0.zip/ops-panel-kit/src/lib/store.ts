// The smallest surface for using JSON files as the database. No DB to operate; just the three
// guards that keep it from breaking:
//   1) write to a temp file, then rename (a power cut never leaves half-written JSON)
//   2) unreadable JSON returns the fallback instead of throwing (the screen stays up)
//   3) keep one .bak generation before each write
// If more than one process writes here, add a lock. With a single process you do not need one.
import { promises as fs } from "node:fs";
import path from "node:path";

const DATA_DIR = process.env.PANEL_DATA_DIR?.trim() || path.join(process.cwd(), "data");

export function dataPath(name: string): string {
  if (!/^[\w.-]+$/.test(name)) throw new Error(`invalid file name: ${name}`);
  return path.join(DATA_DIR, name);
}

export async function readJson<T>(name: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(dataPath(name), "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function writeJson(name: string, value: unknown): Promise<void> {
  const file = dataPath(name);
  await fs.mkdir(path.dirname(file), { recursive: true });
  try {
    await fs.copyFile(file, `${file}.bak`);
  } catch {
    // Nothing to copy on the first write. Keep going.
  }
  const tmp = `${file}.tmp-${process.pid}`;
  await fs.writeFile(tmp, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(tmp, file);
}

/** read → change → write in one call, so you can hand it a pure function and nothing else. */
export async function updateJson<T>(name: string, fallback: T, change: (current: T) => T): Promise<T> {
  const next = change(await readJson<T>(name, fallback));
  await writeJson(name, next);
  return next;
}
