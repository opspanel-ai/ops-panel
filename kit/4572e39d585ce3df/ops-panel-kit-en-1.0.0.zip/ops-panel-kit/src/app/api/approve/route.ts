// The approval surface. The OK button on the screen and the Telegram reply both come through here,
// so the decision lives in exactly one place.
import { NextResponse } from "next/server";
import { readJson, writeJson } from "@/lib/store";
import { DEFAULT_APPROVAL, formatRequest, nextAction, parseReply, type Approval } from "@/lib/approval-core";
import { poll, sendMessage, telegramReady } from "@/lib/telegram";

export const dynamic = "force-dynamic";

const FILE = "approval.json";

interface Stored {
  current: Approval | null;
  offset: number;
}

const EMPTY: Stored = { current: null, offset: 0 };

export async function GET() {
  const stored = await readJson<Stored>(FILE, EMPTY);
  return NextResponse.json({ ...stored, next: nextAction(stored.current, DEFAULT_APPROVAL, Date.now()), telegram: telegramReady() });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const op = typeof body.op === "string" ? body.op : "";
  const stored = await readJson<Stored>(FILE, EMPTY);

  if (op === "ask") {
    const subject = typeof body.subject === "string" ? body.subject : "confirm";
    const detail = typeof body.detail === "string" ? body.detail : "";
    const current: Approval = { subject, decision: "pending", askedMs: Date.now(), decidedMs: 0 };
    await writeJson(FILE, { ...stored, current });
    await sendMessage(formatRequest(subject, detail, DEFAULT_APPROVAL));
    return NextResponse.json({ ok: true });
  }

  if (op === "decide") {
    const decision = body.decision === "ok" ? "ok" : "ng";
    if (!stored.current) return NextResponse.json({ ok: false, error: "nothing is awaiting approval" }, { status: 400 });
    await writeJson(FILE, { ...stored, current: { ...stored.current, decision, decidedMs: Date.now() } });
    return NextResponse.json({ ok: true });
  }

  if (op === "poll") {
    const incoming = await poll(stored.offset);
    let next = stored;
    for (const msg of incoming) {
      next = { ...next, offset: Math.max(next.offset, msg.updateId + 1) };
      const reply = parseReply(msg.text);
      if (reply && next.current && next.current.decision === "pending") {
        next = { ...next, current: { ...next.current, decision: reply, decidedMs: Date.now() } };
      }
    }
    await writeJson(FILE, next);
    return NextResponse.json({ ok: true, read: incoming.length, current: next.current });
  }

  return NextResponse.json({ ok: false, error: `unknown op: ${op}` }, { status: 400 });
}
