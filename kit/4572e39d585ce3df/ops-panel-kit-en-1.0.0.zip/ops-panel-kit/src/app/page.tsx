"use client";

import { useCallback, useEffect, useState } from "react";
import type { Task, TaskCounts, TaskStatus } from "@/lib/tasks-core";

interface Payload {
  today: string;
  tasks: Task[];
  counts: TaskCounts;
}

const EMPTY: Payload = { today: "", tasks: [], counts: { todo: 0, doing: 0, done: 0, overdue: 0 } };

export default function Page() {
  const [data, setData] = useState<Payload>(EMPTY);
  const [title, setTitle] = useState("");

  const load = useCallback(async () => {
    const res = await fetch("/api/tasks", { cache: "no-store" });
    if (res.ok) setData((await res.json()) as Payload);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const send = useCallback(
    async (body: Record<string, string>) => {
      await fetch("/api/tasks", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      await load();
    },
    [load],
  );

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await send({ op: "add", title });
    setTitle("");
  };

  const next: Record<TaskStatus, TaskStatus> = { todo: "doing", doing: "done", done: "todo" };

  return (
    <main>
      <h1>Today&apos;s tasks</h1>
      <p className="sub">{data.today}</p>

      <div className="card counts">
        <div>todo<b>{data.counts.todo}</b></div>
        <div>doing<b>{data.counts.doing}</b></div>
        <div>done<b>{data.counts.done}</b></div>
        <div>overdue<b>{data.counts.overdue}</b></div>
      </div>

      <div className="card">
        {data.tasks.length === 0 && <p className="empty">Nothing to do.</p>}
        {data.tasks.map((t) => (
          <div key={t.id} className={`row ${t.status === "done" ? "done" : ""}`}>
            <button onClick={() => void send({ op: "status", id: t.id, status: next[t.status] })}>
              {t.status === "todo" ? "□" : t.status === "doing" ? "◐" : "■"}
            </button>
            <span className="title">{t.title}</span>
            {t.due && <span className={`due ${data.today && t.due < data.today ? "over" : ""}`}>{t.due}</span>}
            <button onClick={() => void send({ op: "remove", id: t.id })}>remove</button>
          </div>
        ))}
      </div>

      <form onSubmit={(e) => void add(e)} className="card">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Write a task and press Enter" />
        <button className="primary" type="submit">add</button>
      </form>
    </main>
  );
}
