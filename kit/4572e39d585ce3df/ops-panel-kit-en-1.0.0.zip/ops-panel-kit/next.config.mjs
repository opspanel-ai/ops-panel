/** @type {import('next').NextConfig} */
// Built to run on your own PC: `pnpm build` then `pnpm start` serves 127.0.0.1:4320.
//
// output: "standalone" is deliberately not used — on Windows the build fails with EPERM unless the
// account may create symlinks (developer mode or admin). A default should not demand that.
//
// outputFileTracingRoot is pinned to this folder — with another lockfile in a parent directory
// Next.js picks the wrong root and warns. Harmless, but it costs you time working out why.
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));

const nextConfig = {
  reactStrictMode: true,
  outputFileTracingRoot: here,
};
export default nextConfig;
