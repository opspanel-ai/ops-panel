# Ops Panel Kit

A minimal, working skeleton for **your own internal dashboard, running on your own PC**.
No server to rent, no database to operate. What is here is only the part that stays the same
whatever your business does — you add the business on top.

## Run it in 15 minutes

```bash
pnpm install
cp .env.example .env     # Windows: copy
pnpm dev                 # http://127.0.0.1:4320
```

If "Today's tasks" renders, you are done. Data lands in `data/tasks.json`. No database involved.

## What's inside

| Path | Role |
|---|---|
| `src/lib/tasks-core.ts` | The code that *decides*. Pure functions, no I/O, testable as-is |
| `src/lib/approval-core.ts` | "Wait for a human before the risky step" — as a pure decision |
| `src/lib/store.ts` | JSON files used as the database, without the usual ways they break |
| `src/lib/telegram.ts` | Telegram without webhooks (`getUpdates`): no fixed IP, no tunnel, no open port |
| `src/app/api/*` | The HTTP surface for the screen and for anything calling in |
| `scripts/backup.mjs` | Copies `data/` **outside the repository**, keeping generations |
| `scripts/deploy.mjs` | The gate: types → tests → build. Stops on the first failure |
| `scripts/install-task.ps1` | Registers the panel with Windows Task Scheduler so it comes back by itself |
| `prompts/*.md` | The prompts I hand to an AI agent (change request / article draft / cover image) |

## The five ideas this is built on

1. **Separate deciding from touching.** Decisions live in `*-core.ts` as pure functions; no `fs`,
   no `fetch`, no clock. Tests become plain function calls, and when an AI agent edits the code you
   can hand it only the decision layer — which is where most accidents stop happening.
2. **Use JSON as the database, but handle the three ways it breaks.** Write to a temp file and
   `rename` (no half-written file after a power cut), fall back to a default on unreadable JSON
   (the screen keeps rendering), and copy the data **outside the repo** on a schedule (what you lose
   in a bad `git` moment is the data, never the code).
3. **Keep approval in one place.** The button on the screen and the reply in the chat app both go
   through `approval-core`. Two entry points with two sets of rules means one of them silently goes stale.
4. **Decide up front what happens when nobody answers.** An automation that waits forever for approval
   stops being used, because you are not watching most of the time. Every approval carries a wait time
   and a default action.
5. **Only what passes the gate ships.** `scripts/deploy.mjs` runs types, tests and build in order.
   When an AI writes the code, a machine rejecting it first is faster and more reliable than you reading it.

## Keep it running (Windows)

```powershell
powershell -ExecutionPolicy Bypass -File scripts/install-task.ps1
schtasks /run /tn ops-panel
```

Stop with `schtasks /end /tn ops-panel`, remove with `schtasks /delete /tn ops-panel /f`.

Pitfalls that cost me time, already handled in the script: trigger **at startup** (not at logon, or it
will not come back while you are away), **no execution time limit** (the default kills it after three
days), restart on failure, and do not stop on battery.

## Backups

```bash
PANEL_BACKUP_DIR=D:/panel-backups node scripts/backup.mjs
```

Run it every 30 minutes from Task Scheduler as well. **Point it outside the repository.**

## Telegram approvals

1. Create a bot with BotFather, put the token in `.env` as `PANEL_TELEGRAM_TOKEN`
2. Send the bot a message once
3. Put your chat id in `PANEL_TELEGRAM_CHAT_ID`
4. `POST /api/approve {"op":"ask","subject":"Publish the article","detail":"..."}`
5. Poll with `POST /api/approve {"op":"poll"}` to pick up the OK / NG reply

No webhook means no port forwarding and no static IP.

## Working with an AI agent

1. Write **one** request in `prompts/improve.md` and hand it over
2. Let the agent edit
3. Make the agent keep going until `node scripts/deploy.mjs --check` passes
4. Then build and swap the running panel

**Never hand over two requests at once.** When it breaks you will not know which one did it, and you
end up reverting both. One at a time keeps the revert small.

## Deliberately not included

Auth, multi-user, permissions, third-party integrations, charts. All of them are easy to add later,
and **adding them before your actual work is defined leaves you maintaining features nobody uses.**

License: `LICENSE-KIT.md`.
