// Copies data/ outside the repository. What a bad git command or a broken build destroys is never
// the code you wrote — it is the data you accumulated. Keeps generations, drops the oldest.
//   node scripts/backup.mjs            30 generations by default
//   PANEL_BACKUP_DIR=D:/backups node scripts/backup.mjs
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";

const DATA = process.env.PANEL_DATA_DIR?.trim() || path.join(process.cwd(), "data");
const DEST = process.env.PANEL_BACKUP_DIR?.trim() || path.join(os.homedir(), "panel-backups");
const KEEP = Number(process.env.PANEL_BACKUP_KEEP || 30);

const stamp = () => new Date(Date.now() + 9 * 3600_000).toISOString().replace(/[-:T]/g, "").slice(0, 14);

async function main() {
  const files = await fs.readdir(DATA).catch(() => []);
  const json = files.filter((f) => f.endsWith(".json"));
  if (json.length === 0) {
    console.log("nothing to back up:", DATA);
    return;
  }
  const dir = path.join(DEST, stamp());
  await fs.mkdir(dir, { recursive: true });
  for (const f of json) await fs.copyFile(path.join(DATA, f), path.join(dir, f));
  console.log(`backed up ${json.length} file(s) -> ${dir}`);

  const gens = (await fs.readdir(DEST)).filter((d) => /^\d{14}$/.test(d)).sort();
  for (const old of gens.slice(0, Math.max(0, gens.length - KEEP))) {
    await fs.rm(path.join(DEST, old), { recursive: true, force: true });
    console.log("removed old generation:", old);
  }
}

main().catch((e) => {
  console.error("backup failed:", e.message);
  process.exit(1);
});
