// Runs types → tests → build in order and stops at the first failure. Only a clean run swaps the
// running panel. If an AI writes the code, always put it through this gate: a machine rejecting it
// first is faster and more reliable than you reading the diff.
//   node scripts/deploy.mjs          all the way through the build
//   node scripts/deploy.mjs --check  checks only, no build
import { spawnSync } from "node:child_process";

const CHECK_ONLY = process.argv.includes("--check");
// On Windows pnpm is a .cmd, which Node 20+ refuses to spawn directly, so it goes through a shell.
// Passing an args array with shell: true triggers DEP0190, so the command is one string.
// Everything in that string is a literal below; nothing from outside reaches it.
const steps = [
  ["type check", "pnpm typecheck"],
  ["tests", "pnpm test"],
  ...(CHECK_ONLY ? [] : [["build", "pnpm build"]]),
];

for (const [label, command] of steps) {
  process.stdout.write(`\n== ${label}\n`);
  const r = spawnSync(command, { stdio: "inherit", shell: true });
  if (r.status !== 0) {
    console.error(`\n✗ ${label} failed. Stopping here — nothing is swapped.`);
    process.exit(1);
  }
}
console.log("\n✓ everything passed.");
