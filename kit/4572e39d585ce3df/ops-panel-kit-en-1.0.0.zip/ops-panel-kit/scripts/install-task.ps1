# Keeps the panel running on your own PC even while you are not logged in (Windows Task Scheduler).
# No hosting bill. If it dies it comes back by itself.
#   powershell -ExecutionPolicy Bypass -File scripts/install-task.ps1
param(
  [string]$TaskName = "ops-panel",
  [string]$Port = "4320"
)

$root = Split-Path -Parent $PSScriptRoot
$node = (Get-Command node).Source
$start = Join-Path $root "scripts\run-panel.cmd"

@"
@echo off
cd /d "$root"
call pnpm build
call pnpm start
"@ | Set-Content -Encoding ASCII $start

$action   = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$start`"" -WorkingDirectory $root
$trigger  = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -RunLevel Highest -Force | Out-Null
Write-Host "registered: $TaskName (http://127.0.0.1:$Port)"
Write-Host "node: $node"
Write-Host "start:  schtasks /run /tn $TaskName"
Write-Host "remove: schtasks /delete /tn $TaskName /f"
