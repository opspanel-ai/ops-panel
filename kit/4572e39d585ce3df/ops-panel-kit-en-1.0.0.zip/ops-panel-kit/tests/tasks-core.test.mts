import assert from "node:assert/strict";
import test from "node:test";
import { countTasks, dueToday, makeTask, normalizeTasks, setStatus } from "../src/lib/tasks-core.ts";

test("drops broken saved entries", () => {
  const list = normalizeTasks([{ title: "alive" }, { title: "   " }, null, 5, { title: "with due", due: "2026-01-02", status: "doing" }]);
  assert.equal(list.length, 2);
  assert.equal(list[1]?.due, "2026-01-02");
  assert.equal(list[1]?.status, "doing");
});

test("invalid dates and states fall back to defaults", () => {
  const list = normalizeTasks([{ title: "x", due: "2026/01/02", status: "burning" }]);
  assert.equal(list[0]?.due, "");
  assert.equal(list[0]?.status, "todo");
});

test("due today sorts by due date then creation, no-due last", () => {
  const base = [
    { id: "a", title: "no due date", status: "todo" as const, due: "", createdMs: 1 },
    { id: "b", title: "day after", status: "todo" as const, due: "2026-03-03", createdMs: 2 },
    { id: "c", title: "yesterday", status: "todo" as const, due: "2026-03-01", createdMs: 3 },
    { id: "d", title: "done", status: "done" as const, due: "2026-03-01", createdMs: 4 },
  ];
  assert.deepEqual(dueToday(base, "2026-03-02").map((t) => t.id), ["c", "a"]);
});

test("counts overdue", () => {
  const list = normalizeTasks([
    { title: "late", due: "2026-03-01" },
    { title: "today", due: "2026-03-02" },
    { title: "done", due: "2026-02-01", status: "done" },
  ]);
  assert.deepEqual(countTasks(list, "2026-03-02"), { todo: 2, doing: 0, done: 1, overdue: 1 });
});

test("makeTask rejects an empty title / status can be changed", () => {
  assert.equal(makeTask("  ", "", 1), null);
  const t = makeTask("groceries", "2026-03-02", 1);
  assert.ok(t);
  assert.equal(setStatus([t], t.id, "done")[0]?.status, "done");
});
