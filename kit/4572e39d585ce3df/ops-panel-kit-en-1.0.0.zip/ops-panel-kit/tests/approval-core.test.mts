import assert from "node:assert/strict";
import test from "node:test";
import { DEFAULT_APPROVAL, formatRequest, nextAction, parseReply, type Approval } from "../src/lib/approval-core.ts";

const asked = (askedMs: number): Approval => ({ subject: "publish the article", decision: "pending", askedMs, decidedMs: 0 });

test("reads OK / NG", () => {
  assert.equal(parseReply("OK"), "ok");
  assert.equal(parseReply("sure"), "ok");
  assert.equal(parseReply("/note ok"), "ok");
  assert.equal(parseReply("cancel"), "ng");
  assert.equal(parseReply("later maybe"), null);
});

test("waits when there is no approval", () => {
  assert.deepEqual(nextAction(null, DEFAULT_APPROVAL, 0), { kind: "wait", untilMs: 0 });
});

test("waits for a reply, then falls back to the default", () => {
  const a = asked(0);
  assert.equal(nextAction(a, DEFAULT_APPROVAL, 59 * 60_000).kind, "wait");
  assert.deepEqual(nextAction(a, DEFAULT_APPROVAL, 60 * 60_000), { kind: "skip", via: "silent" });
  assert.deepEqual(nextAction(a, { waitMin: 60, silentDefault: "publish" }, 60 * 60_000), { kind: "run", via: "silent" });
});

test("a human reply beats the default", () => {
  assert.deepEqual(nextAction({ ...asked(0), decision: "ok" }, DEFAULT_APPROVAL, 0), { kind: "run", via: "human" });
  assert.deepEqual(nextAction({ ...asked(0), decision: "ng" }, { waitMin: 1, silentDefault: "publish" }, 9e9), { kind: "skip", via: "human" });
});

test("the request text carries the wait and the default", () => {
  const text = formatRequest("publish the article", "title: test", DEFAULT_APPROVAL);
  assert.match(text, /60 minutes/);
  assert.match(text, /skipped/);
});
